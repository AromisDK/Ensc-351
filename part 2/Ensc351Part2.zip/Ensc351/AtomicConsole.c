/*
 * AtomicCOUT.cpp
 *
 *  Created on: Sep 24, 2010
 *      Author: wcs
 */

#include <pthread.h>

pthread_mutex_t consoleMutex = PTHREAD_MUTEX_INITIALIZER;
